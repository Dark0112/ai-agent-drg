
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
import openai, os, json
from PyPDF2 import PdfReader

app = FastAPI()
openai.api_key = os.getenv("OPENAI_API_KEY")

with open("data/ar_drg.json", "r", encoding="utf-8") as f:
    AR_DRG = json.load(f)

def extract_text(file):
    reader = PdfReader(file)
    text = ""
    for page in reader.pages:
        text += page.extract_text() or ""
    return text

def analyze_text(text):
    prompt = f"""You are a clinical AI assistant.
Extract from the report:
1. ICD-10 code
2. Age, Sex
3. Key symptoms
4. Assign DRG complexity (MAJC / INTC / MINC)
5. Suggest DRG code if applicable.
Return result as JSON only.
---
{text}"""
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )
    return json.loads(response.choices[0].message.content)

def match_drg(icd_code, complexity):
    for row in AR_DRG:
        if row["icd_code"] == icd_code and row["complexity"] == complexity:
            return row
    return {}

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    contents = await file.read()
    text = extract_text(contents)
    result = analyze_text(text)
    drg = match_drg(result.get("icd"), result.get("complexity"))
    return JSONResponse(content={"analysis": result, "drg": drg})
